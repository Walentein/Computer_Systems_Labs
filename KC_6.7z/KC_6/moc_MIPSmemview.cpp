/****************************************************************************
** Meta object code from reading C++ file 'MIPSmemview.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "GUI/MIPSmemview.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MIPSmemview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MIPSmemview[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      13,   12,   12,   12, 0x0a,
      26,   12,   12,   12, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_MIPSmemview[] = {
    "MIPSmemview\0\0updateList()\0initList()\0"
};

void MIPSmemview::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MIPSmemview *_t = static_cast<MIPSmemview *>(_o);
        switch (_id) {
        case 0: _t->updateList(); break;
        case 1: _t->initList(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData MIPSmemview::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject MIPSmemview::staticMetaObject = {
    { &Q3ListBox::staticMetaObject, qt_meta_stringdata_MIPSmemview,
      qt_meta_data_MIPSmemview, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MIPSmemview::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MIPSmemview::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MIPSmemview::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MIPSmemview))
        return static_cast<void*>(const_cast< MIPSmemview*>(this));
    return Q3ListBox::qt_metacast(_clname);
}

int MIPSmemview::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Q3ListBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
